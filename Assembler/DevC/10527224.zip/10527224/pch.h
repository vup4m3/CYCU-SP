#ifndef PCH_H
#define PCH_H

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <iomanip>
#endif // !PCH_H
